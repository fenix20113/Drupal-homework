jQuery Countdown Timer
==============================

This module provides a block with a jQuery countdown timer.

Installation.
=============

1. Unzip the files to the "sites/all/modules" directory and enable the module.

2. Go to the admin/structure/block page to enable and configure the jQuery 
Countdown Timer block.

Credit
======

The module utilises the jQuery Countdown Timer script written by Martin Angelov:
http://tutorialzine.com/2011/12/countdown-jquery/


